function validateForm() {
    var name = document.forms["contactform"]["name"].value;
    var phone = document.forms["contactform"]["phone"].value;
    var email = document.forms["contactform"]["email"].value;
    var comment = document.forms["contactform"]["comment"].value;

    // Simple validation
    if (name.trim() == "") {
        alert("Name must be filled out");
        return false;
    }
    if (phone.trim() == "") {
        alert("Phone number must be filled out");
        return false;
    }
    if (email.trim() == "") {
        alert("Email must be filled out");
        return false;
    }
    if (comment.trim() == "") {
        alert("Message must be filled out");
        return false;
    }

    // Additional validation for email format
    var emailRegex = /^\S+@\S+\.\S+$/;
    if (!emailRegex.test(email)) {
        alert("Invalid email format");
        return false;
    }

    return true;
}